-----------------------------------
---------- By Weez#8876 -----------
------- Weez Developpement --------
-- https://discord.gg/BK7hTKub8e --
-----------------------------------

fx_version 'adamant'
game 'gta5'

client_scripts {
    "wz_cl.lua",
}

ui_page 'html/ui.html'

files {
	'html/ui.html',
	'html/css/style.css',
	'html/js/main.js',
	'html/img/*',
	'html/fonts/*'
}
